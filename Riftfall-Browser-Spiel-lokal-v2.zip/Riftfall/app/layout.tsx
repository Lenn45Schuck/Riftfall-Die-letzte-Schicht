import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
    title: 'Riftfall – Die letzte Schicht',
    description: 'Ein 2D-Action-Survival-Spiel in der verlassenen Forschungsstation.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
    return <html lang="de"><body>{children}</body></html>;
}
