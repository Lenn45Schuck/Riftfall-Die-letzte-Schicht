'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
    Crosshair,
    Gamepad2,
    Pause,
    Play,
    RotateCcw,
    Shield,
    Skull,
    Sparkles,
    Target,
    Trophy,
    Zap,
} from 'lucide-react';
import styles from './riftfall.module.css';

type Phase = 'start' | 'playing' | 'paused' | 'upgrade' | 'gameover' | 'victory';
type EnemyKind = 'crawler' | 'shard' | 'sentinel' | 'warden' | 'boss';
type UpgradeId =
    | 'pulse'
    | 'overcharge'
    | 'hull'
    | 'phase'
    | 'scatter'
    | 'cryo'
    | 'salvage'
    | 'reactor';

type Point = { x: number; y: number };

type Player = Point & {
    radius: number;
    speed: number;
    hp: number;
    maxHp: number;
    damage: number;
    fireRate: number;
    fireCooldown: number;
    bulletSpeed: number;
    projectiles: number;
    critChance: number;
    slow: number;
    xp: number;
    xpToNext: number;
    level: number;
    xpMultiplier: number;
    invulnerable: number;
    hurtFlash: number;
}

type Enemy = Point & {
    id: number;
    kind: EnemyKind;
    radius: number;
    hp: number;
    maxHp: number;
    speed: number;
    damage: number;
    cooldown: number;
    shootCooldown: number;
    rotation: number;
    phaseTimer: number;
    pattern: number;
    dead?: boolean;
};

type Bullet = Point & {
    vx: number;
    vy: number;
    radius: number;
    damage: number;
    life: number;
    from: 'player' | 'enemy';
    pierce: number;
    color: string;
};

type Particle = Point & {
    vx: number;
    vy: number;
    life: number;
    maxLife: number;
    size: number;
    color: string;
};

type GameState = {
    width: number;
    height: number;
    player: Player;
    enemies: Enemy[];
    bullets: Bullet[];
    particles: Particle[];
    wave: number;
    score: number;
    kills: number;
    time: number;
    spawnQueue: EnemyKind[];
    spawnTimer: number;
    nextEnemyId: number;
    bossStarted: boolean;
    awaitingUpgrade: boolean;
    waveBannerUntil: number;
};

type Hud = {
    hp: number;
    maxHp: number;
    xp: number;
    xpToNext: number;
    level: number;
    wave: number;
    score: number;
    kills: number;
    bossHp: number;
    bossMaxHp: number;
};

type InputState = {
    keys: Set<string>;
    mouse: Point & { down: boolean; hasMoved: boolean };
};

type Upgrade = {
    id: UpgradeId;
    name: string;
    eyebrow: string;
    description: string;
    value: string;
    icon: typeof Zap;
    color: string;
};

const WAVE_COMPOSITIONS: Record<number, EnemyKind[]> = {
    1: ['crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'shard', 'shard'],
    2: ['crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'shard', 'shard', 'shard', 'sentinel'],
    3: ['crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'shard', 'shard', 'shard', 'sentinel', 'sentinel', 'warden'],
    4: ['crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'shard', 'shard', 'shard', 'shard', 'sentinel', 'sentinel', 'sentinel', 'warden', 'warden'],
    5: ['crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'crawler', 'shard', 'shard', 'shard', 'shard', 'shard', 'sentinel', 'sentinel', 'sentinel', 'sentinel', 'warden', 'warden', 'warden'],
};

const UPGRADE_LIBRARY: Upgrade[] = [
    { id: 'pulse', name: 'Pulsfrequenz', eyebrow: 'WAFFENMODUL', description: 'Die Impulskanone lädt schneller und hält Gegner auf Abstand.', value: '+22 % Feuerrate', icon: Zap, color: '#7de8ff' },
    { id: 'overcharge', name: 'Überladung', eyebrow: 'WAFFENMODUL', description: 'Mehr Energie wird in jeden Schuss geleitet.', value: '+28 % Schaden', icon: Crosshair, color: '#ffbd70' },
    { id: 'hull', name: 'Verstärkte Hülle', eyebrow: 'SYSTEMMODUL', description: 'Neue Keramikplatten stabilisieren den Reaktorkern.', value: '+30 max. HP · Heilung', icon: Shield, color: '#9aaeff' },
    { id: 'phase', name: 'Phasenstiefel', eyebrow: 'SYSTEMMODUL', description: 'Die Feldstiefel verschieben dich einen Schritt aus der Gefahrenzone.', value: '+18 % Bewegungstempo', icon: Gamepad2, color: '#b893ff' },
    { id: 'scatter', name: 'Splitterschuss', eyebrow: 'WAFFENMODUL', description: 'Jeder Impuls teilt sich in einen zusätzlichen Projektilpfad.', value: '+1 Projektil', icon: Target, color: '#ff8cac' },
    { id: 'cryo', name: 'Kryo-Munition', eyebrow: 'WAFFENMODUL', description: 'Getroffene Gegner verlieren Geschwindigkeit.', value: 'Gegner −20 % Tempo', icon: Sparkles, color: '#79d8d2' },
    { id: 'salvage', name: 'Bergungsprotokoll', eyebrow: 'PROTOKOLL', description: 'Die Station extrahiert mehr verwertbare Erfahrung aus jedem Ziel.', value: '+25 % Erfahrung', icon: Trophy, color: '#f6d77b' },
    { id: 'reactor', name: 'Arc-Reaktor', eyebrow: 'SYSTEMMODUL', description: 'Kritische Entladungen treffen die Schwachstellen der Risswesen.', value: '+12 % Krit-Chance', icon: Skull, color: '#ff8d70' },
];

const ENEMY_COLORS: Record<EnemyKind, string> = {
    crawler: '#ff6b79',
    shard: '#ffbd70',
    sentinel: '#7de8ff',
    warden: '#b893ff',
    boss: '#ff6d98',
};

function clamp(value: number, min: number, max: number) {
    return Math.max(min, Math.min(max, value));
}

function distance(a: Point, b: Point) {
    return Math.hypot(a.x - b.x, a.y - b.y);
}

function createPlayer(width: number, height: number): Player {
    return {
        x: width / 2,
        y: height / 2,
        radius: 15,
        speed: 238,
        hp: 100,
        maxHp: 100,
        damage: 17,
        fireRate: 4.7,
        fireCooldown: 0,
        bulletSpeed: 620,
        projectiles: 1,
        critChance: 0.08,
        slow: 0,
        xp: 0,
        xpToNext: 85,
        level: 1,
        xpMultiplier: 1,
        invulnerable: 0,
        hurtFlash: 0,
    };
}

function createGameState(width: number, height: number): GameState {
    return {
        width,
        height,
        player: createPlayer(width, height),
        enemies: [],
        bullets: [],
        particles: [],
        wave: 1,
        score: 0,
        kills: 0,
        time: 0,
        spawnQueue: [],
        spawnTimer: 0,
        nextEnemyId: 1,
        bossStarted: false,
        awaitingUpgrade: false,
        waveBannerUntil: 0,
    };
}

function queueWave(state: GameState, wave: number) {
    state.wave = wave;
    state.spawnQueue = [...WAVE_COMPOSITIONS[wave]];
    state.spawnTimer = 0.25;
    state.waveBannerUntil = state.time + 2;
    state.awaitingUpgrade = false;
}

function randomEdgePosition(state: GameState): Point {
    const edge = Math.floor(Math.random() * 4);
    const pad = 45;
    if (edge === 0) return { x: pad, y: pad + Math.random() * Math.max(1, state.height - pad * 2) };
    if (edge === 1) return { x: state.width - pad, y: pad + Math.random() * Math.max(1, state.height - pad * 2) };
    if (edge === 2) return { x: pad + Math.random() * Math.max(1, state.width - pad * 2), y: pad };
    return { x: pad + Math.random() * Math.max(1, state.width - pad * 2), y: state.height - pad };
}

function spawnEnemy(state: GameState, kind: EnemyKind) {
    const position = kind === 'boss'
        ? { x: state.width / 2, y: Math.max(116, state.height * 0.22) }
        : randomEdgePosition(state);
    const scale = 1 + (state.wave - 1) * 0.12;
    const base: Record<EnemyKind, Omit<Enemy, 'id' | 'x' | 'y' | 'kind' | 'dead'>> = {
        crawler: { radius: 13, hp: 40 * scale, maxHp: 40 * scale, speed: 74 + state.wave * 3, damage: 9, cooldown: 0, shootCooldown: 0, rotation: 0, phaseTimer: 0, pattern: 0 },
        shard: { radius: 12, hp: 28 * scale, maxHp: 28 * scale, speed: 132 + state.wave * 4, damage: 11, cooldown: 0, shootCooldown: 0, rotation: 0, phaseTimer: 1.5, pattern: 0 },
        sentinel: { radius: 16, hp: 74 * scale, maxHp: 74 * scale, speed: 52 + state.wave * 2, damage: 12, cooldown: 0, shootCooldown: 1.2, rotation: 0, phaseTimer: 0, pattern: 0 },
        warden: { radius: 21, hp: 175 * scale, maxHp: 175 * scale, speed: 31 + state.wave, damage: 17, cooldown: 0, shootCooldown: 0, rotation: 0, phaseTimer: 0, pattern: 0 },
        boss: { radius: 54, hp: 1200, maxHp: 1200, speed: 28, damage: 24, cooldown: 0, shootCooldown: 0.8, rotation: 0, phaseTimer: 1.6, pattern: 1 },
    };
    state.enemies.push({ id: state.nextEnemyId++, kind, ...position, ...base[kind] });
}

function burst(state: GameState, x: number, y: number, color: string, amount = 10, power = 90) {
    for (let i = 0; i < amount; i += 1) {
        const angle = Math.random() * Math.PI * 2;
        const speed = power * (0.35 + Math.random() * 0.9);
        state.particles.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, life: 0.35 + Math.random() * 0.5, maxLife: 0.85, size: 1.5 + Math.random() * 3.5, color });
    }
}

function drawUpgradeChoices(): Upgrade[] {
    const shuffled = [...UPGRADE_LIBRARY].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 3);
}

function applyUpgrade(state: GameState, id: UpgradeId) {
    const player = state.player;
    if (id === 'pulse') player.fireRate *= 1.22;
    if (id === 'overcharge') player.damage *= 1.28;
    if (id === 'hull') { player.maxHp += 30; player.hp = Math.min(player.maxHp, player.hp + 30); }
    if (id === 'phase') player.speed *= 1.18;
    if (id === 'scatter') player.projectiles = Math.min(5, player.projectiles + 1);
    if (id === 'cryo') player.slow = Math.min(0.6, player.slow + 0.2);
    if (id === 'salvage') player.xpMultiplier *= 1.25;
    if (id === 'reactor') player.critChance = Math.min(0.65, player.critChance + 0.12);
}

function formatNumber(value: number) {
    return Math.round(value).toLocaleString('de-DE');
}

function drawBackground(ctx: CanvasRenderingContext2D, state: GameState) {
    const gradient = ctx.createLinearGradient(0, 0, state.width, state.height);
    gradient.addColorStop(0, '#07121e');
    gradient.addColorStop(0.52, '#0a1a2b');
    gradient.addColorStop(1, '#0b111d');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, state.width, state.height);

    ctx.save();
    ctx.globalAlpha = 0.14;
    ctx.strokeStyle = '#77b6d6';
    ctx.lineWidth = 1;
    const grid = 52;
    const offset = (state.time * 8) % grid;
    for (let x = -grid + offset; x < state.width + grid; x += grid) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, state.height); ctx.stroke();
    }
    for (let y = -grid + offset; y < state.height + grid; y += grid) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(state.width, y); ctx.stroke();
    }
    ctx.restore();

    ctx.save();
    ctx.strokeStyle = '#a8ddf426';
    ctx.lineWidth = 2;
    ctx.setLineDash([9, 14]);
    const inset = 26;
    ctx.strokeRect(inset, inset, state.width - inset * 2, state.height - inset * 2);
    ctx.setLineDash([]);
    ctx.strokeStyle = '#7de8ff1c';
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(state.width * 0.2, 26); ctx.lineTo(state.width * 0.2, state.height * 0.22); ctx.lineTo(26, state.height * 0.22); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(state.width - 26, state.height * 0.76); ctx.lineTo(state.width * 0.78, state.height * 0.76); ctx.lineTo(state.width * 0.78, state.height - 26); ctx.stroke();
    ctx.restore();

    const cx = state.width / 2;
    const cy = state.height / 2;
    const rift = ctx.createRadialGradient(cx, cy, 14, cx, cy, Math.min(state.width, state.height) * 0.3);
    rift.addColorStop(0, '#6be9ff2d');
    rift.addColorStop(0.22, '#7de8ff12');
    rift.addColorStop(1, '#7de8ff00');
    ctx.fillStyle = rift;
    ctx.fillRect(0, 0, state.width, state.height);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(state.time * 0.08);
    ctx.strokeStyle = '#7de8ff24';
    ctx.lineWidth = 1;
    for (let i = 0; i < 3; i += 1) {
        ctx.beginPath();
        ctx.ellipse(0, 0, 62 + i * 18, 18 + i * 9, i * 0.4, 0, Math.PI * 2);
        ctx.stroke();
    }
    ctx.restore();
}

function drawPlayer(ctx: CanvasRenderingContext2D, state: GameState, aimAngle: number) {
    const player = state.player;
    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.rotate(aimAngle + Math.PI / 2);
    ctx.shadowBlur = 25;
    ctx.shadowColor = '#7de8ff';
    ctx.fillStyle = player.hurtFlash > 0 ? '#ffffff' : '#7de8ff';
    ctx.beginPath();
    ctx.moveTo(0, -20);
    ctx.lineTo(13, 16);
    ctx.lineTo(0, 11);
    ctx.lineTo(-13, 16);
    ctx.closePath();
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#102538';
    ctx.beginPath(); ctx.arc(0, 1, 5, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#d7fbff'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(-10, 11); ctx.lineTo(-18, 17); ctx.moveTo(10, 11); ctx.lineTo(18, 17); ctx.stroke();
    ctx.restore();

    if (player.invulnerable > 0) {
        ctx.save();
        ctx.globalAlpha = 0.55 + Math.sin(state.time * 22) * 0.2;
        ctx.strokeStyle = '#d9fbff';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(player.x, player.y, 25, 0, Math.PI * 2); ctx.stroke();
        ctx.restore();
    }
}

function drawEnemy(ctx: CanvasRenderingContext2D, enemy: Enemy, time: number) {
    const color = ENEMY_COLORS[enemy.kind];
    ctx.save();
    ctx.translate(enemy.x, enemy.y);
    ctx.rotate(enemy.rotation);
    ctx.shadowColor = color;
    ctx.shadowBlur = enemy.kind === 'boss' ? 36 : 16;
    ctx.fillStyle = color;
    ctx.strokeStyle = '#ffffff66';
    ctx.lineWidth = 1.5;

    if (enemy.kind === 'crawler') {
        ctx.beginPath();
        ctx.moveTo(0, -enemy.radius); ctx.lineTo(enemy.radius, 0); ctx.lineTo(0, enemy.radius); ctx.lineTo(-enemy.radius, 0); ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#3a1528'; ctx.beginPath(); ctx.arc(0, 0, 4, 0, Math.PI * 2); ctx.fill();
    } else if (enemy.kind === 'shard') {
        ctx.beginPath();
        ctx.moveTo(0, -enemy.radius - 4); ctx.lineTo(enemy.radius, enemy.radius); ctx.lineTo(-enemy.radius, enemy.radius); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#4b2a16'; ctx.beginPath(); ctx.arc(0, 5, 3, 0, Math.PI * 2); ctx.fill();
    } else if (enemy.kind === 'sentinel') {
        ctx.beginPath(); ctx.arc(0, 0, enemy.radius, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#132c3c'; ctx.beginPath(); ctx.arc(0, 0, 7, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#d6faff'; ctx.beginPath(); ctx.arc(0, 0, enemy.radius - 5, 0, Math.PI * 1.2); ctx.stroke();
    } else if (enemy.kind === 'warden') {
        ctx.beginPath();
        for (let i = 0; i < 6; i += 1) {
            const angle = (Math.PI * 2 * i) / 6;
            const px = Math.cos(angle) * enemy.radius;
            const py = Math.sin(angle) * enemy.radius;
            if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#221b3f'; ctx.beginPath(); ctx.arc(0, 0, 8, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#f3e9ff'; ctx.beginPath(); ctx.arc(0, 0, enemy.radius - 6, time % 2, time % 2 + Math.PI * 1.1); ctx.stroke();
    } else {
        ctx.beginPath(); ctx.arc(0, 0, enemy.radius, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
        ctx.strokeStyle = '#ffd2e1aa'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.arc(0, 0, enemy.radius - 8, time * 1.4, time * 1.4 + Math.PI * 1.5); ctx.stroke();
        ctx.strokeStyle = '#2b1225'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(-17, -5); ctx.lineTo(17, 5); ctx.moveTo(-13, 12); ctx.lineTo(13, -12); ctx.stroke();
        ctx.fillStyle = '#fff0f7'; ctx.beginPath(); ctx.arc(0, 0, 7 + Math.sin(time * 5) * 1.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();

    if (enemy.kind !== 'boss' && enemy.hp < enemy.maxHp) {
        const width = enemy.radius * 2.4;
        ctx.fillStyle = '#07101dcc'; ctx.fillRect(enemy.x - width / 2, enemy.y - enemy.radius - 10, width, 3);
        ctx.fillStyle = color; ctx.fillRect(enemy.x - width / 2, enemy.y - enemy.radius - 10, width * clamp(enemy.hp / enemy.maxHp, 0, 1), 3);
    }
}

function drawBullet(ctx: CanvasRenderingContext2D, bullet: Bullet) {
    ctx.save();
    ctx.shadowColor = bullet.color;
    ctx.shadowBlur = 13;
    ctx.fillStyle = bullet.color;
    ctx.beginPath(); ctx.arc(bullet.x, bullet.y, bullet.radius, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
}

export default function RiftfallPage() {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const gameRef = useRef<GameState>(createGameState(960, 600));
    const phaseRef = useRef<Phase>('start');
    const inputRef = useRef<InputState>({ keys: new Set(), mouse: { x: 480, y: 300, down: false, hasMoved: false } });
    const dprRef = useRef(1);
    const frameRef = useRef<number | null>(null);
    const noticeTimerRef = useRef<number | null>(null);
    const [phase, setPhase] = useState<Phase>('start');
    const [hud, setHud] = useState<Hud>({ hp: 100, maxHp: 100, xp: 0, xpToNext: 85, level: 1, wave: 1, score: 0, kills: 0, bossHp: 0, bossMaxHp: 0 });
    const [upgradeChoices, setUpgradeChoices] = useState<Upgrade[]>([]);
    const [upgradeReason, setUpgradeReason] = useState<'level' | 'wave' | 'boss'>('level');
    const [notice, setNotice] = useState('');
    const [bestScore, setBestScore] = useState(0);

    const showNotice = useCallback((message: string) => {
        setNotice(message);
        if (noticeTimerRef.current !== null) window.clearTimeout(noticeTimerRef.current);
        noticeTimerRef.current = window.setTimeout(() => setNotice(''), 2600);
    }, []);

    const syncHud = useCallback(() => {
        const state = gameRef.current;
        const boss = state.enemies.find(enemy => enemy.kind === 'boss');
        setHud({
            hp: Math.max(0, state.player.hp), maxHp: state.player.maxHp, xp: state.player.xp, xpToNext: state.player.xpToNext,
            level: state.player.level, wave: state.wave, score: state.score, kills: state.kills,
            bossHp: boss?.hp ?? 0, bossMaxHp: boss?.maxHp ?? 0,
        });
    }, []);

    const startGame = useCallback(() => {
        const canvas = canvasRef.current;
        const width = canvas?.clientWidth || 960;
        const height = canvas?.clientHeight || 600;
        const state = createGameState(width, height);
        queueWave(state, 1);
        gameRef.current = state;
        phaseRef.current = 'playing';
        inputRef.current.keys.clear();
        inputRef.current.mouse.down = false;
        setUpgradeChoices([]);
        setNotice('');
        setPhase('playing');
        window.requestAnimationFrame(syncHud);
        canvas?.focus();
    }, [syncHud]);

    const resumeGame = useCallback(() => {
        phaseRef.current = 'playing';
        setPhase('playing');
    }, []);

    const pauseGame = useCallback(() => {
        if (phaseRef.current !== 'playing') return;
        phaseRef.current = 'paused';
        setPhase('paused');
    }, []);

    const chooseUpgrade = useCallback((upgrade: Upgrade) => {
        const state = gameRef.current;
        applyUpgrade(state, upgrade.id);
        state.awaitingUpgrade = false;
        setUpgradeChoices([]);
        if (upgradeReason === 'boss') {
            phaseRef.current = 'playing';
            setPhase('playing');
            syncHud();
            return;
        }
        if (upgradeReason === 'wave') {
            if (state.wave >= 5) {
                state.bossStarted = true;
                state.enemies = [];
                state.bullets = [];
                spawnEnemy(state, 'boss');
                showNotice('RISSKERN DETEKTIERT');
            } else {
                queueWave(state, state.wave + 1);
                showNotice(`WELLE ${state.wave} EINGELEITET`);
            }
        }
        phaseRef.current = 'playing';
        setPhase('playing');
        syncHud();
    }, [syncHud, upgradeReason]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let lastFrame = performance.now();
        let lastHudSync = 0;
        let resizeObserver: ResizeObserver | null = null;

        const resize = () => {
            const rect = canvas.getBoundingClientRect();
            const width = Math.max(320, rect.width);
            const height = Math.max(420, rect.height);
            const dpr = Math.min(window.devicePixelRatio || 1, 2);
            dprRef.current = dpr;
            canvas.width = Math.round(width * dpr);
            canvas.height = Math.round(height * dpr);
            gameRef.current.width = width;
            gameRef.current.height = height;
            gameRef.current.player.x = clamp(gameRef.current.player.x, 34, width - 34);
            gameRef.current.player.y = clamp(gameRef.current.player.y, 34, height - 34);
            inputRef.current.mouse.x = clamp(inputRef.current.mouse.x, 0, width);
            inputRef.current.mouse.y = clamp(inputRef.current.mouse.y, 0, height);
        };
        resize();
        resizeObserver = new ResizeObserver(resize);
        resizeObserver.observe(canvas);

        const pointerPosition = (event: PointerEvent) => {
            const rect = canvas.getBoundingClientRect();
            inputRef.current.mouse.x = clamp(event.clientX - rect.left, 0, rect.width);
            inputRef.current.mouse.y = clamp(event.clientY - rect.top, 0, rect.height);
            inputRef.current.mouse.hasMoved = true;
        };

        const findAimAngle = (state: GameState) => {
            const input = inputRef.current;
            if (input.mouse.hasMoved) return Math.atan2(input.mouse.y - state.player.y, input.mouse.x - state.player.x);
            const nearest = state.enemies.reduce<{ enemy: Enemy | null; distance: number }>((closest, enemy) => {
                const currentDistance = distance(state.player, enemy);
                return currentDistance < closest.distance ? { enemy, distance: currentDistance } : closest;
            }, { enemy: null, distance: Number.POSITIVE_INFINITY });
            if (nearest.enemy) return Math.atan2(nearest.enemy.y - state.player.y, nearest.enemy.x - state.player.x);
            return -Math.PI / 2;
        };

        const addExperience = (state: GameState, amount: number) => {
            state.player.xp += amount * state.player.xpMultiplier;
            if (state.player.xp >= state.player.xpToNext && !state.awaitingUpgrade) {
                state.player.xp -= state.player.xpToNext;
                state.player.level += 1;
                state.player.xpToNext = Math.round(state.player.xpToNext * 1.3);
                state.awaitingUpgrade = true;
                setUpgradeReason('level');
                setUpgradeChoices(drawUpgradeChoices());
                phaseRef.current = 'upgrade';
                setPhase('upgrade');
                showNotice('SYSTEM-UPGRADE VERFÜGBAR');
            }
        };

        const defeatEnemy = (state: GameState, enemy: Enemy) => {
            if (enemy.dead) return;
            enemy.dead = true;
            state.kills += 1;
            const points = enemy.kind === 'boss' ? 5000 : enemy.kind === 'warden' ? 420 : enemy.kind === 'sentinel' ? 260 : enemy.kind === 'shard' ? 180 : 110;
            state.score += points;
            const xp = enemy.kind === 'boss' ? 0 : enemy.kind === 'warden' ? 34 : enemy.kind === 'sentinel' ? 22 : enemy.kind === 'shard' ? 15 : 12;
            addExperience(state, xp);
            burst(state, enemy.x, enemy.y, ENEMY_COLORS[enemy.kind], enemy.kind === 'boss' ? 58 : 15, enemy.kind === 'boss' ? 180 : 80);
            if (enemy.kind === 'boss') {
                phaseRef.current = 'victory';
                setPhase('victory');
                showNotice('STATIONSYSTEM STABILISIERT');
            }
        };

        const damagePlayer = (state: GameState, amount: number) => {
            const player = state.player;
            if (player.invulnerable > 0 || phaseRef.current !== 'playing') return;
            player.hp -= amount;
            player.invulnerable = 0.65;
            player.hurtFlash = 0.22;
            burst(state, player.x, player.y, '#ff7b8d', 8, 65);
            if (player.hp <= 0) {
                player.hp = 0;
                phaseRef.current = 'gameover';
                setPhase('gameover');
                showNotice('REAKTORKERN AUSGEFALLEN');
                setBestScore(previous => Math.max(previous, state.score));
            }
        };

        const spawnEnemyBullet = (state: GameState, x: number, y: number, angle: number, speed: number, damage: number, color: string, radius = 5) => {
            state.bullets.push({ x, y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, radius, damage, life: 4, from: 'enemy', pierce: 0, color });
        };

        const update = (state: GameState, dt: number) => {
            if (phaseRef.current !== 'playing') return;
            state.time += dt;
            const player = state.player;
            player.fireCooldown = Math.max(0, player.fireCooldown - dt);
            player.invulnerable = Math.max(0, player.invulnerable - dt);
            player.hurtFlash = Math.max(0, player.hurtFlash - dt);

            if (state.spawnQueue.length > 0) {
                state.spawnTimer -= dt;
                if (state.spawnTimer <= 0) {
                    spawnEnemy(state, state.spawnQueue.shift() as EnemyKind);
                    state.spawnTimer = Math.max(0.23, 0.68 - state.wave * 0.05);
                }
            }

            const input = inputRef.current;
            let moveX = 0;
            let moveY = 0;
            if (input.keys.has('KeyA') || input.keys.has('ArrowLeft')) moveX -= 1;
            if (input.keys.has('KeyD') || input.keys.has('ArrowRight')) moveX += 1;
            if (input.keys.has('KeyW') || input.keys.has('ArrowUp')) moveY -= 1;
            if (input.keys.has('KeyS') || input.keys.has('ArrowDown')) moveY += 1;
            const length = Math.hypot(moveX, moveY) || 1;
            player.x = clamp(player.x + (moveX / length) * player.speed * dt, 32, state.width - 32);
            player.y = clamp(player.y + (moveY / length) * player.speed * dt, 32, state.height - 32);

            const firing = input.mouse.down || input.keys.has('Space') || input.keys.has('KeyJ');
            if (firing && player.fireCooldown <= 0) {
                const angle = findAimAngle(state);
                const count = player.projectiles;
                const spread = count === 1 ? 0 : Math.min(0.44, 0.16 * (count - 1));
                for (let i = 0; i < count; i += 1) {
                    const offset = count === 1 ? 0 : -spread + (2 * spread * i) / (count - 1);
                    const shotAngle = angle + offset;
                    const critical = Math.random() < player.critChance;
                    state.bullets.push({ x: player.x + Math.cos(shotAngle) * 18, y: player.y + Math.sin(shotAngle) * 18, vx: Math.cos(shotAngle) * player.bulletSpeed, vy: Math.sin(shotAngle) * player.bulletSpeed, radius: critical ? 5 : 3.5, damage: player.damage * (critical ? 2 : 1), life: 1.35, from: 'player', pierce: player.projectiles >= 4 ? 1 : 0, color: critical ? '#ffd785' : '#a9f3ff' });
                }
                player.fireCooldown = 1 / player.fireRate;
                burst(state, player.x + Math.cos(angle) * 14, player.y + Math.sin(angle) * 14, '#7de8ff', 3, 34);
            }

            for (const enemy of state.enemies) {
                if (enemy.dead) continue;
                enemy.rotation += dt * (enemy.kind === 'boss' ? 0.32 : 0.8);
                enemy.cooldown = Math.max(0, enemy.cooldown - dt);
                enemy.shootCooldown = Math.max(0, enemy.shootCooldown - dt);
                const dx = player.x - enemy.x;
                const dy = player.y - enemy.y;
                const currentDistance = Math.hypot(dx, dy) || 1;
                const angleToPlayer = Math.atan2(dy, dx);
                if (enemy.kind === 'sentinel') {
                    const desiredDistance = 250;
                    const direction = currentDistance > desiredDistance ? 1 : currentDistance < desiredDistance * 0.72 ? -1 : 0;
                    enemy.x += Math.cos(angleToPlayer) * enemy.speed * direction * dt;
                    enemy.y += Math.sin(angleToPlayer) * enemy.speed * direction * dt;
                    if (enemy.shootCooldown <= 0) {
                        spawnEnemyBullet(state, enemy.x, enemy.y, angleToPlayer, 185 + state.wave * 7, enemy.damage, '#7de8ff');
                        enemy.shootCooldown = Math.max(0.82, 1.7 - state.wave * 0.1);
                    }
                } else if (enemy.kind === 'boss') {
                    enemy.x += Math.cos(state.time * 0.55) * enemy.speed * dt;
                    enemy.y += Math.sin(state.time * 0.8) * enemy.speed * 0.45 * dt;
                    enemy.x = clamp(enemy.x, 110, state.width - 110);
                    enemy.y = clamp(enemy.y, 96, state.height * 0.45);
                    enemy.phaseTimer -= dt;
                    if (enemy.phaseTimer <= 0) {
                        enemy.pattern = enemy.pattern === 1 ? 2 : 1;
                        if (enemy.pattern === 1) {
                            for (let i = 0; i < 14; i += 1) spawnEnemyBullet(state, enemy.x, enemy.y, (Math.PI * 2 * i) / 14 + state.time * 0.2, 145, enemy.damage * 0.6, '#ff83ad', 5);
                            enemy.phaseTimer = 2.5;
                        } else {
                            for (let i = -2; i <= 2; i += 1) spawnEnemyBullet(state, enemy.x, enemy.y, angleToPlayer + i * 0.12, 240, enemy.damage * 0.85, '#ffc07c', 5);
                            enemy.phaseTimer = 1.55;
                        }
                        burst(state, enemy.x, enemy.y, ENEMY_COLORS.boss, 14, 120);
                    }
                } else {
                    const speedMultiplier = enemy.kind === 'shard' ? (enemy.phaseTimer < 0.35 ? 2.3 : 1) : 1;
                    enemy.x += (dx / currentDistance) * enemy.speed * speedMultiplier * (1 - player.slow) * dt;
                    enemy.y += (dy / currentDistance) * enemy.speed * speedMultiplier * (1 - player.slow) * dt;
                    if (enemy.kind === 'shard') {
                        enemy.phaseTimer -= dt;
                        if (enemy.phaseTimer <= -0.1) enemy.phaseTimer = 1.5 + Math.random() * 0.7;
                    }
                }

                const collisionDistance = player.radius + enemy.radius;
                if (distance(player, enemy) < collisionDistance && enemy.cooldown <= 0) {
                    damagePlayer(state, enemy.damage);
                    enemy.cooldown = enemy.kind === 'boss' ? 1.2 : 0.85;
                }
            }

            for (const bullet of state.bullets) {
                bullet.x += bullet.vx * dt;
                bullet.y += bullet.vy * dt;
                bullet.life -= dt;
            }

            for (const bullet of state.bullets) {
                if (bullet.from === 'player') {
                    for (const enemy of state.enemies) {
                        if (enemy.dead || distance(bullet, enemy) > bullet.radius + enemy.radius) continue;
                        enemy.hp -= bullet.damage;
                        burst(state, bullet.x, bullet.y, bullet.color, 2, 22);
                        if (enemy.hp <= 0) defeatEnemy(state, enemy);
                        bullet.life = bullet.pierce > 0 ? bullet.life : 0;
                        if (bullet.pierce > 0) bullet.pierce -= 1;
                        break;
                    }
                } else if (distance(bullet, player) < bullet.radius + player.radius) {
                    damagePlayer(state, bullet.damage);
                    bullet.life = 0;
                }
            }
            state.bullets = state.bullets.filter(bullet => bullet.life > 0 && bullet.x > -50 && bullet.x < state.width + 50 && bullet.y > -50 && bullet.y < state.height + 50);
            state.enemies = state.enemies.filter(enemy => !enemy.dead);

            for (const particle of state.particles) {
                particle.x += particle.vx * dt;
                particle.y += particle.vy * dt;
                particle.vx *= 0.96;
                particle.vy *= 0.96;
                particle.life -= dt;
            }
            state.particles = state.particles.filter(particle => particle.life > 0);

            if (phaseRef.current === 'playing' && !state.awaitingUpgrade && !state.bossStarted && state.spawnQueue.length === 0 && state.enemies.length === 0 && state.time > state.waveBannerUntil + 0.4) {
                state.awaitingUpgrade = true;
                setUpgradeReason('wave');
                setUpgradeChoices(drawUpgradeChoices());
                phaseRef.current = 'upgrade';
                setPhase('upgrade');
                showNotice(`WELLE ${state.wave} GESICHERT`);
            }
        };

        const render = (state: GameState) => {
            const dpr = dprRef.current;
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
            ctx.clearRect(0, 0, state.width, state.height);
            drawBackground(ctx, state);
            for (const particle of state.particles) {
                ctx.save(); ctx.globalAlpha = clamp(particle.life / particle.maxLife, 0, 1); ctx.fillStyle = particle.color; ctx.shadowColor = particle.color; ctx.shadowBlur = 10; ctx.beginPath(); ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2); ctx.fill(); ctx.restore();
            }
            for (const bullet of state.bullets) drawBullet(ctx, bullet);
            for (const enemy of state.enemies) drawEnemy(ctx, enemy, state.time);
            const aimAngle = Math.atan2(inputRef.current.mouse.y - state.player.y, inputRef.current.mouse.x - state.player.x);
            drawPlayer(ctx, state, aimAngle);
            if (state.waveBannerUntil > state.time && phaseRef.current === 'playing') {
                const remaining = state.waveBannerUntil - state.time;
                ctx.save(); ctx.globalAlpha = clamp(remaining < 0.45 ? remaining / 0.45 : 1, 0, 1);
                ctx.fillStyle = '#d8f9ff'; ctx.textAlign = 'center'; ctx.font = '600 14px ui-monospace, SFMono-Regular, Menlo, monospace'; ctx.letterSpacing = '0.2em';
                ctx.fillText(state.bossStarted ? 'RISSKERN' : `WELLE ${state.wave}`, state.width / 2, state.height * 0.2);
                ctx.restore();
            }
        };

        const loop = (now: number) => {
            const dt = Math.min(0.034, (now - lastFrame) / 1000);
            lastFrame = now;
            const state = gameRef.current;
            update(state, dt);
            render(state);
            if (now - lastHudSync > 90) {
                lastHudSync = now;
                syncHud();
            }
            frameRef.current = window.requestAnimationFrame(loop);
        };

        const onKeyDown = (event: KeyboardEvent) => {
            if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.code)) event.preventDefault();
            if (event.code === 'Escape') {
                if (phaseRef.current === 'playing') pauseGame();
                else if (phaseRef.current === 'paused') resumeGame();
                return;
            }
            if (event.code === 'Enter' && (phaseRef.current === 'start' || phaseRef.current === 'gameover' || phaseRef.current === 'victory')) { startGame(); return; }
            inputRef.current.keys.add(event.code);
        };
        const onKeyUp = (event: KeyboardEvent) => inputRef.current.keys.delete(event.code);
        const onPointerMove = (event: PointerEvent) => pointerPosition(event);
        const onPointerDown = (event: PointerEvent) => { pointerPosition(event); inputRef.current.mouse.down = true; canvas.setPointerCapture(event.pointerId); };
        const onPointerUp = (event: PointerEvent) => { inputRef.current.mouse.down = false; if (canvas.hasPointerCapture(event.pointerId)) canvas.releasePointerCapture(event.pointerId); };
        window.addEventListener('keydown', onKeyDown);
        window.addEventListener('keyup', onKeyUp);
        canvas.addEventListener('pointermove', onPointerMove);
        canvas.addEventListener('pointerdown', onPointerDown);
        canvas.addEventListener('pointerup', onPointerUp);
        canvas.addEventListener('pointercancel', onPointerUp);
        frameRef.current = window.requestAnimationFrame(loop);

        return () => {
            if (frameRef.current) window.cancelAnimationFrame(frameRef.current);
            resizeObserver?.disconnect();
            window.removeEventListener('keydown', onKeyDown);
            window.removeEventListener('keyup', onKeyUp);
            canvas.removeEventListener('pointermove', onPointerMove);
            canvas.removeEventListener('pointerdown', onPointerDown);
            canvas.removeEventListener('pointerup', onPointerUp);
            canvas.removeEventListener('pointercancel', onPointerUp);
        };
    }, [pauseGame, resumeGame, showNotice, startGame, syncHud]);

    useEffect(() => {
        try {
            const stored = window.localStorage.getItem('riftfall-best-score');
            if (stored) setBestScore(Number(stored));
        } catch { /* local storage is optional */ }
    }, []);

    useEffect(() => {
        if (phase === 'gameover' || phase === 'victory') {
            try { window.localStorage.setItem('riftfall-best-score', String(Math.max(bestScore, hud.score))); } catch { /* local storage is optional */ }
        }
    }, [bestScore, hud.score, phase]);

    const hpPercent = clamp((hud.hp / Math.max(1, hud.maxHp)) * 100, 0, 100);
    const xpPercent = clamp((hud.xp / Math.max(1, hud.xpToNext)) * 100, 0, 100);
    const bossPercent = clamp((hud.bossHp / Math.max(1, hud.bossMaxHp)) * 100, 0, 100);

    const pressTouchKey = (code: string, pressed: boolean) => {
        if (pressed) inputRef.current.keys.add(code); else inputRef.current.keys.delete(code);
    };

    return (
        <div className={styles.gameShell}>
            <div className={styles.gameWrap}>
                <div className={styles.gameHeader}>
                    <div>
                        <div className={styles.kicker}><span className={styles.signalDot} /> Forschungsstation // Sektor 07</div>
                        <h1>Riftfall <span>– Die letzte Schicht</span></h1>
                    </div>
                    <div className={styles.headerTag}><span>RUN</span><strong>RF–05</strong></div>
                </div>

                <div className={styles.stage}>
                    <canvas ref={canvasRef} className={styles.canvas} tabIndex={0} aria-label="Riftfall Spielfeld" />

                    <div className={styles.hud} aria-live="polite">
                        <div className={styles.hudBlock}>
                            <div className={styles.hudLabel}><Shield size={13} /> Reaktorkern <span>{Math.ceil(hud.hp)} / {hud.maxHp}</span></div>
                            <div className={styles.bar}><span className={styles.hpBar} style={{ width: `${hpPercent}%` }} /></div>
                        </div>
                        <div className={styles.waveReadout}><small>SEKTOR</small><strong>{hud.wave < 6 ? `0${hud.wave}` : 'BOSS'}</strong><span>{hud.wave < 6 ? '/ 05 Wellen' : 'Risskern'}</span></div>
                        <div className={styles.hudBlockRight}>
                            <div className={styles.statLine}><span>Score</span><strong>{formatNumber(hud.score)}</strong></div>
                            <div className={styles.statLine}><span>Ziele</span><strong>{hud.kills.toString().padStart(2, '0')}</strong></div>
                        </div>
                    </div>

                    <div className={styles.xpHud}>
                        <div className={styles.xpMeta}><span>LEVEL {hud.level.toString().padStart(2, '0')}</span><span>{Math.floor(hud.xp)} / {hud.xpToNext} XP</span></div>
                        <div className={styles.xpBar}><span style={{ width: `${xpPercent}%` }} /></div>
                    </div>

                    {hud.bossMaxHp > 0 && phase !== 'victory' && <div className={styles.bossHud}><div><span>RISSKERN // ENDGEGNER</span><strong>{Math.ceil(hud.bossHp)} HP</strong></div><div className={styles.bossBar}><span style={{ width: `${bossPercent}%` }} /></div></div>}

                    <button className={styles.pauseButton} onClick={pauseGame} aria-label="Spiel pausieren" disabled={phase !== 'playing'}><Pause size={16} /></button>

                    {notice && phase === 'playing' && <div className={styles.notice}>{notice}</div>}

                    {phase === 'start' && <div className={styles.overlay}>
                        <div className={styles.startPanel}>
                            <div className={styles.riftMark}><span /></div>
                            <div className={styles.panelKicker}>NOTFALLPROTOKOLL 05 // 03:17 UTC</div>
                            <h2>Die Station<br /><em>fällt.</em></h2>
                            <p>Ein Riss hat die Forschungsstation geöffnet. Halte fünf Wellen durch, verbessere dein Loadout und schließe den Risskern.</p>
                            <button className={styles.primaryButton} onClick={startGame}><Play size={17} fill="currentColor" /> Mission starten</button>
                            <div className={styles.controlStrip}><span><kbd>WASD</kbd> bewegen</span><span><kbd>Maus</kbd> zielen</span><span><kbd>Klick</kbd> feuern</span><span><kbd>ESC</kbd> Pause</span></div>
                        </div>
                    </div>}

                    {phase === 'paused' && <div className={styles.overlay}>
                        <div className={styles.pausePanel}><div className={styles.panelKicker}>SIGNAL HALTED // PAUSE</div><h2>System pausiert.</h2><p>Der Reaktorkern wartet. Deine Position und dein Loadout bleiben erhalten.</p><div className={styles.panelActions}><button className={styles.primaryButton} onClick={resumeGame}><Play size={17} fill="currentColor" /> Fortsetzen</button><button className={styles.ghostButton} onClick={startGame}><RotateCcw size={16} /> Neustart</button></div></div>
                    </div>}

                    {phase === 'upgrade' && <div className={styles.overlay}>
                        <div className={styles.upgradePanel}>
                            <div className={styles.panelKicker}>{upgradeReason === 'wave' ? `WELLE ${hud.wave} GESICHERT` : 'LEVEL-UP // SYSTEM ONLINE'}</div>
                            <h2>{upgradeReason === 'wave' ? 'Zeit für ein Upgrade.' : 'Wähle deine Verstärkung.'}</h2>
                            <p>{upgradeReason === 'wave' ? 'Die nächste Welle wartet hinter dem Schleusentor. Sichere dir eine neue Systemmodifikation.' : 'Nur ein Modul kann in dieser Schicht synchronisiert werden.'}</p>
                            <div className={styles.upgradeGrid}>
                                {upgradeChoices.map(upgrade => {
                                    const Icon = upgrade.icon;
                                    return <button key={upgrade.id} className={styles.upgradeCard} onClick={() => chooseUpgrade(upgrade)} style={{ '--accent': upgrade.color } as React.CSSProperties}><span className={styles.upgradeIcon}><Icon size={20} /></span><span className={styles.upgradeEyebrow}>{upgrade.eyebrow}</span><strong>{upgrade.name}</strong><span className={styles.upgradeDescription}>{upgrade.description}</span><span className={styles.upgradeValue}>{upgrade.value}</span></button>;
                                })}
                            </div>
                        </div>
                    </div>}

                    {phase === 'gameover' && <div className={styles.overlay}>
                        <div className={styles.endPanel}><div className={styles.endIcon}><Skull size={25} /></div><div className={styles.panelKicker}>SIGNAL LOST // MISSION ABORTED</div><h2>Die letzte Schicht<br /><em>endet hier.</em></h2><p>Der Reaktorkern wurde überrannt. Jede Welle bringt dich näher an den Ursprung des Risses.</p><div className={styles.resultGrid}><div><span>SCORE</span><strong>{formatNumber(hud.score)}</strong></div><div><span>WELLE</span><strong>{hud.wave} / 05</strong></div><div><span>BESTER SCORE</span><strong>{formatNumber(Math.max(bestScore, hud.score))}</strong></div></div><button className={styles.primaryButton} onClick={startGame}><RotateCcw size={17} /> Erneut versuchen</button><small className={styles.enterHint}>Enter drücken zum Neustart</small></div>
                    </div>}

                    {phase === 'victory' && <div className={styles.overlay}>
                        <div className={`${styles.endPanel} ${styles.victory}`}><div className={styles.endIcon}><Trophy size={25} /></div><div className={styles.panelKicker}>RISS GESCHLOSSEN // STATION STABIL</div><h2>Du hast die Schicht<br /><em>überlebt.</em></h2><p>Der Risskern ist versiegelt. Die Station schweigt wieder – zumindest bis zum nächsten Alarm.</p><div className={styles.resultGrid}><div><span>SCORE</span><strong>{formatNumber(hud.score)}</strong></div><div><span>ZIELE</span><strong>{hud.kills.toString().padStart(2, '0')}</strong></div><div><span>BESTER SCORE</span><strong>{formatNumber(Math.max(bestScore, hud.score))}</strong></div></div><button className={styles.primaryButton} onClick={startGame}><RotateCcw size={17} /> Neue Schicht</button><small className={styles.enterHint}>Enter drücken zum Neustart</small></div>
                    </div>}

                    <div className={styles.touchControls} aria-label="Touch-Steuerung">
                        <div className={styles.dPad}><button onPointerDown={() => pressTouchKey('KeyW', true)} onPointerUp={() => pressTouchKey('KeyW', false)} onPointerLeave={() => pressTouchKey('KeyW', false)} aria-label="Nach oben">↑</button><div><button onPointerDown={() => pressTouchKey('KeyA', true)} onPointerUp={() => pressTouchKey('KeyA', false)} onPointerLeave={() => pressTouchKey('KeyA', false)} aria-label="Nach links">←</button><button onPointerDown={() => pressTouchKey('KeyS', true)} onPointerUp={() => pressTouchKey('KeyS', false)} onPointerLeave={() => pressTouchKey('KeyS', false)} aria-label="Nach unten">↓</button><button onPointerDown={() => pressTouchKey('KeyD', true)} onPointerUp={() => pressTouchKey('KeyD', false)} onPointerLeave={() => pressTouchKey('KeyD', false)} aria-label="Nach rechts">→</button></div></div>
                        <button className={styles.fireTouch} onPointerDown={() => { inputRef.current.mouse.down = true; }} onPointerUp={() => { inputRef.current.mouse.down = false; }} onPointerLeave={() => { inputRef.current.mouse.down = false; }} aria-label="Feuern"><Crosshair size={25} /></button>
                    </div>
                </div>

                <div className={styles.gameFooter}><span><span className={styles.liveDot} /> LIVE-SIMULATION</span><span>Fünf Wellen // Vier Gegnertypen // Ein Risskern</span><span>BEST <strong>{formatNumber(bestScore)}</strong></span></div>
            </div>
        </div>
    );
}
