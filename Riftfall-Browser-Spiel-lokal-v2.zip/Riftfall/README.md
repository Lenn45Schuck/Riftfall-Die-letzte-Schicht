# Riftfall – Die letzte Schicht

Ein eigenständiges Browser-Spiel für Safari. Die S&P-Business-Website ist nicht enthalten.

## Start auf macOS

1. Node.js 22.13 oder neuer installieren.
2. `start-local.command` doppelklicken. Falls macOS fragt, die Datei mit **Öffnen** bestätigen.
3. Das Skript installiert die Abhängigkeiten und öffnet Safari unter [http://localhost:3000](http://localhost:3000).

Zum Beenden im geöffneten Terminal `Ctrl+C` drücken.

## Steuerung

- `WASD`: bewegen
- Maus: zielen
- Mausklick: feuern
- `ESC`: pausieren
- Auf Touch-Geräten erscheinen zusätzliche Steuerflächen.
