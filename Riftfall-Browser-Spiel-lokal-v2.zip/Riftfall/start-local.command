#!/bin/zsh
set -euo pipefail

ROOT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT_DIR"

if ! command -v node >/dev/null 2>&1; then
    echo "Node.js 22.13 oder neuer wird benötigt."
    read -r "?Zum Beenden Enter drücken..."
    exit 1
fi

if command -v pnpm >/dev/null 2>&1; then
    PM=(pnpm)
elif command -v corepack >/dev/null 2>&1; then
    PM=(corepack pnpm)
else
    echo "pnpm oder Corepack wurde nicht gefunden. Installiere Node.js 22.13 oder neuer."
    read -r "?Zum Beenden Enter drücken..."
    exit 1
fi

echo "Abhängigkeiten werden vorbereitet..."
"${PM[@]}" install --frozen-lockfile
echo "Riftfall läuft unter http://localhost:3000"
(sleep 4; open -a Safari "http://localhost:3000") &
"${PM[@]}" run dev
